export class Cart {
    id: number ;
    itemName: string | undefined;
    itemPrice: number | undefined;
    itemDetails: string | undefined;
}
